#!/bin/bash

#Kis Aranka-Eniko
#621-es csoport
#kaam0346

# ellenorzom, hogy legyen legalabb egy parameter megadva, ha 0 vagy annal kevesebb van, hibauzanet es megallok
if [  $# -le 0 ]
then echo Hasznalat $0 felhasznalonev bbimnnnn vagy bbamnnnn vagy bbmmnnnn
exit 1
fi
 
# ellenorzom, hogy tenyleg letezo felhasznalonevet adott meg, ha igen kiirom a folyamatainak a szamat
max=0
nev=()
for user_id in $@
do
    if ! id -u $user_id >/dev/null 2>/dev/null
    then 
        echo  $user_id nem letezik!
    else 
        echo $user_id : ` ps -u $user_id -o comm= | wc -l`
        if [ `ps -u $user_id -o comm= | wc -l` -ge $max ]
        then 
            max=`ps -u $user_id -o comm= | wc -l`
	    nev+=("$user_id")
        fi
    fi
done

#a lementett nev(ek)(neki(k) van a legtobb folyamata/folyamatuk) folyamatainak a nevet irja ki uj sorba az osszeset
hossz=${#nev[@]}
for ((i=0; i<$hossz; i++))
do
	if [ $max -eq `ps -u ${nev[$i]} -o comm= | wc -l` ]
		then
			echo ${nev[$i]}
	 		ps -u  ${nev[$i]} -o comm=|sort -u
	fi
 done

