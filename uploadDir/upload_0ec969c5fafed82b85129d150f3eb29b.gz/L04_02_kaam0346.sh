#!/bin/bash

#Kis Aranka-Eniko, 621-es csoport, kaam0346

# ellenorzom a parametereket
#ha nincs legalabb 2 parameter, akkor hibauzenet es kilepek
if [  $# -le 1 ]
then echo "Hasznalat $0 szo filenev"
exit 1
fi

szo=$1
db=0
for allomanyok in ${@:2}
do
	if [ -f $allomanyok ]
	then
		if file -b  $allomanyok | grep -q  text 
		then
			if cat $allomanyok | grep -q  $szo
			then
				echo "$allomanyok"
				db=$((db+1))
			fi
		else
			echo "A $allomanyok  allomany nem szoveges"
		fi
	else
		echo "A $allomanyok allomany nem letezik!!"
	fi
done

echo $db
