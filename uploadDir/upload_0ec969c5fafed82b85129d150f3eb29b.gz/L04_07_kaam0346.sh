#!/bin/bash

#Kis Aranka-Eniko, 621-es csoport, kaam0346

# ellenorzom a parametereket
if [  $# -eq 0 ]
then echo Hasznalat $0 szervernev
exit 1 
fi

for szerv in $@
do
	if ping -c1 $szerv 2>/dev/null | grep -q  '100% packet loss'
	then
		echo $szerv - nem elerheto
	elif ping -c1 $szerv 2>/dev/null | grep -q  '0% packet loss'
	then
		echo $szerv - elerheto
	else
		echo $szerv - nem letezik
	fi
done
