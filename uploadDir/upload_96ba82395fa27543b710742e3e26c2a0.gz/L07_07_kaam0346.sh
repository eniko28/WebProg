#! /bin/bash

# Kis Aranka-Eniko, 621-es csoport, kaam0346
#7-es sorszam

if [ $# -le 0 ]
then echo "Hasznalat $0 masodperc(egy szamot kell megadni)!"
	exit 1
fi

# lementem az idot
ido=$1
#lementem a joe iletve vi felhasznalokat es a nevuket is
joefelhasznalok=$(w -h | grep joe | awk '{print $1}' | sort | uniq | wc -l)
vifelhasznalok=$(w -h | grep vim | awk '{print $1}' | sort | uniq | wc -l)
joe_nevek=$(w -h | grep joe | awk '{print $1}' | sort | uniq ) 
vi_nevek=$(w -h | grep vim | awk '{print $1}' | sort | uniq) 
joe_max=$joefelhasznalok
vi_max=$vifelhasznalok
joe_rekord=`date +"%Y-%m-%d %H:%M:%S"`
vi_rekord=`date +"%Y-%m-%d %H:%M:%S"`
vi_atlag=0
joe_atlag=0
db=0
vi_masik=0
joe_masik=0
joe_rekord_masik=''
vi_rekord_masik=''

# felugyeloprogram
while true
do
	((db++))
	ujjoefelhasznalok=''
	ujvifelhasznalok=''
	ujjoefelhasznalok=$(w -h | grep joe | awk '{print $1}' | sort | uniq | wc -l)
        ujvifelhasznalok=$(w -h | grep vim | awk '{print $1}' | sort | uniq | wc -l)
        uj_joe_nevek=$(w -h | grep joe | awk '{print $1}' | sort | uniq )
        uj_vi_nevek=$(w -h | grep vim | awk '{print $1}' | sort | uniq)

	echo "$ujjoefelhasznalok darab felhasznalo futtat joe-t es $ujvifelhasznalok darab felhaszanlo futtat vi(m)-t" | cat >> log
	for i in $vi_nevek
	do
		ok=0
		for j in $uj_vi_nevek
		do
			if [ $j == $i ]
			then
				ok=1
			fi
		done
			if [ $ok -eq 0 ]
			then
				echo "$i egy intelligens felhasznalo :)"
				if [ $(id -g) -eq $(id -g $i) ]
				then
                                        echo "Kedves $i! Gratulalok, hogy sikeresen kileptel a vi(m) programbol :)" | mail -s "Sikeres kilepes a vi(m) programbol" $i
				fi
			fi
	done
	vi_nevek=$uj_vi_nevek
	#12*ido intervallumonkent

	if [ $ujjoefelhasznalok -ge $joe_max ]
	then
		joe_max=$ujjoefelhasznalok
		joe_rekord=$(date +"%Y-%m-%d %H:%M:%S")
	fi
	if [ $ujvifelhasznalok -ge $vi_max ]
	then
		vi_max=$ujvifelhasznalok
		vi_rekord=`date +"%Y-%m-%d %H:%M:%S"`
	fi
	if [ $ujjoefelhasznalok -ge $joe_masik ]
        then
                joe_masik=$ujjoefelhasznalok
                joe_rekord_masik=$(date +"%Y-%m-%d %H:%M:%S")
        fi
        if [ $ujvifelhasznalok -ge $vi_masik ]
        then
                vi_masik=$ujvifelhasznalok
                vi_rekord_masik=`date +"%Y-%m-%d %H:%M:%S"`
        fi

	akt_joe_atlag=$(($akt_joe_atlag+$ujjoefelhasznalok))
	akt_vi_atlag=$(($akt_vi_atlag+$ujvifelhasznalok))

	if [ $db -eq 12 ]
	then
		echo "A program inditasa ota maximum joe felhasznalok szama: $joe_max, utolso rekord: $joe_rekord"
		echo "A program inditasa ota maximum vi(m) felhasznalok szama: $vi_max, utolso rekord: $vi_rekord"
		echo "Az utobbi 12 megfigyeles soran a maximum joe felhasznalok szama: $joe_masik, utolso rekord: $joe_rekord_masik"
                echo "Az utobbi 12 megfigyeles soran a maximum vi(m) felhasznalok szama: $vi_masik, utolso rekord: $vi_rekord_masik"

		akt_vi_atlag_vegleges=$(($akt_vi_atlag / $db))
		akt_joe_atlag_vegleges=$(($akt_joe_atlag / $db))
		
		if [ $akt_joe_atlag_vegleges -gt $joe_atlag ]
		then
			echo "Novekedett a a joe atlag az utobbi 12*ido intervallumon!"
		elif [ $akt_joe_atlag_vegleges -lt $joe_atlag ]
		then
			echo "Csokkent a joe atlag az utobbi 12*ido intervallumon!"
		else
			echo "Nem valtozott a joe atlag az utobbi 12*ido intervallumon!"
		fi
	
		if [ $akt_vi_atlag_vegleges -gt $vi_atlag ]
		then
			echo "Novekedett a a vi atlag az utobbi 12*ido intervallumon!"
		elif [ $akt_vi_atlag_vegleges -lt $vi_atlag ]
		then
			echo "Csokkent a vi atlag az utobbi 12*ido intervallumon!"
		else
			echo "Nem valtozott a vi atlag az utobbi 12*ido intervallumon!!"
		fi
		db=0
		akt_joe_atlag=0
		akt_vi_atlag=0
		joe_atlag=$akt_joe_atlag_vegleges
		vi_atlag=$akt_vi_atlag_vegleges
		joe_masik=0
		joe_rekord_masik=''
		vi_masik=0
		vi_rekord_masik=''
		akt_vi_atlag_12es=0
		akt_joe_atlag_12es=0
	fi
sleep "$ido"
done

